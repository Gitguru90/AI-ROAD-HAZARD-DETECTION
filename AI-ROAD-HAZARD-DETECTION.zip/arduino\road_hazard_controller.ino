/*
  AI ROAD HAZARD DETECTION & SMART SPEED CONTROL SYSTEM
  Arduino Controller Sketch
  
  Baud rate: 9600
  Serial Commands:
    - NORMAL        : Green LED ON, Red & Yellow OFF, Buzzer OFF
    - POTHOLE       : Red LED ON, Green & Yellow OFF, Beep Buzzer
    - SPEED_BREAKER : Yellow LED ON, Green & Red OFF, Beep Buzzer
    - LOW_SPEED     : Speed Reduction Alert
    - STOP          : Emergency Stop
*/

const int PIN_GREEN_LED  = 8;   // Normal Road Clear
const int PIN_RED_LED    = 9;   // Pothole Alert
const int PIN_YELLOW_LED = 10;  // Speed Breaker Alert
const int PIN_BUZZER     = 11;  // Warning Buzzer

String inputBuffer = "";

void setup() {
  Serial.begin(9600);
  
  pinMode(PIN_GREEN_LED, OUTPUT);
  pinMode(PIN_RED_LED, OUTPUT);
  pinMode(PIN_YELLOW_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  // Initial State: Normal / Clear
  setRoadClear();
  Serial.println("SYSTEM_READY");
}

void loop() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (inputBuffer.length() > 0) {
        processCommand(inputBuffer);
        inputBuffer = "";
      }
    } else {
      inputBuffer += c;
    }
  }
}

void processCommand(String cmd) {
  cmd.trim();
  cmd.toUpperCase();

  if (cmd == "NORMAL") {
    setRoadClear();
    Serial.println("ACK:NORMAL");
  } 
  else if (cmd == "POTHOLE") {
    setPotholeAlert();
    Serial.println("ACK:POTHOLE");
  } 
  else if (cmd == "SPEED_BREAKER") {
    setSpeedBreakerAlert();
    Serial.println("ACK:SPEED_BREAKER");
  } 
  else if (cmd == "LOW_SPEED") {
    // Keep hazard LED, ensure slow speed signal
    tone(PIN_BUZZER, 800, 150);
    Serial.println("ACK:LOW_SPEED");
  }
  else if (cmd == "STOP") {
    digitalWrite(PIN_GREEN_LED, LOW);
    digitalWrite(PIN_RED_LED, HIGH);
    digitalWrite(PIN_YELLOW_LED, HIGH);
    tone(PIN_BUZZER, 1500, 500);
    Serial.println("ACK:STOP");
  }
}

void setRoadClear() {
  digitalWrite(PIN_GREEN_LED, HIGH);
  digitalWrite(PIN_RED_LED, LOW);
  digitalWrite(PIN_YELLOW_LED, LOW);
  noTone(PIN_BUZZER);
}

void setPotholeAlert() {
  digitalWrite(PIN_GREEN_LED, LOW);
  digitalWrite(PIN_RED_LED, HIGH);
  digitalWrite(PIN_YELLOW_LED, LOW);
  tone(PIN_BUZZER, 1000, 200); // 1kHz beep for 200ms
}

void setSpeedBreakerAlert() {
  digitalWrite(PIN_GREEN_LED, LOW);
  digitalWrite(PIN_RED_LED, LOW);
  digitalWrite(PIN_YELLOW_LED, HIGH);
  tone(PIN_BUZZER, 600, 200); // 600Hz beep for 200ms
}
